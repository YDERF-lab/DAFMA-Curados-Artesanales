import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Mail, 
  User, 
  MessageSquare, 
  Send, 
  Instagram, 
  Facebook, 
  CheckCircle, 
  MessageCircle, 
  MapPin, 
  ArrowUp
} from "lucide-react";

export default function ContactFooter() {
  const [formData, setFormData] = useState({
    nombre: "",
    email: "",
    mensaje: ""
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);

  // Custom SVG representation for TikTok brand logo
  const TikTokIcon = () => (
    <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
      <path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.17-2.89-.6-4.09-1.5-.77-.57-1.39-1.35-1.77-2.24v8.02c.05 1.52-.3 3.09-1.12 4.38-1.11 1.74-3.03 2.92-5.13 3.1-2.22.18-4.57-.45-6.09-2.11C2.55 18.01 1.83 15.42 2.37 13c.48-2.2 2.06-4.14 4.19-4.88.94-.33 1.95-.44 2.95-.34v4.11c-.72-.14-1.48-.09-2.16.19-.94.38-1.63 1.25-1.78 2.26-.22 1.48.71 2.98 2.19 3.2 1.21.19 2.52-.45 3.01-1.58.26-.59.35-1.25.32-1.9V.02z" />
    </svg>
  );

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.nombre || !formData.email || !formData.mensaje) return;

    setIsSubmitting(true);
    
    // Simulate real communication with backend
    setTimeout(() => {
      setIsSubmitting(false);
      setIsSuccess(true);
      
      // Auto clear after 5 seconds
      setTimeout(() => {
        setIsSuccess(false);
        setFormData({ nombre: "", email: "", mensaje: "" });
      }, 5000);
    }, 1200);
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  // Compose dynamic contact backup mailto / whatsapp if preferred
  const emailSubject = `Contacto DAFMA: De: ${formData.nombre}`;
  const emailBody = `${formData.mensaje} (Mi correo: ${formData.email})`;
  const mailtoLink = `mailto:fdavila15nov@gmail.com?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;

  return (
    <footer id="contacto" className="relative bg-[#fcfaf6] pt-24 pb-12 overflow-hidden border-t border-stone-200">
      {/* Decorative Traditional Border Top */}
      <div className="absolute top-0 left-0 w-full">
        <div className="mexican-border-top" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Contact block grid */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start pb-16 border-b border-stone-200">
          
          {/* Info & Redes sociales column */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <div className="flex items-center gap-2">
                <span className="font-display text-3xl font-black tracking-[0.2em] text-terracotta-955">DAFMA</span>
                <span className="w-2 h-2 rounded-full bg-terracotta-600 animate-pulse" />
              </div>
              <p className="font-sans text-sm text-stone-600 leading-relaxed max-w-sm">
                Tradición líquida oaxaqueña macerada con esmero familiar. Creando mezcales curados de la más alta distinción artesanal para paladares cosmopolitas.
              </p>
            </div>

            {/* Geographical details */}
            <div className="space-y-4 text-xs font-mono text-stone-500 uppercase tracking-wider">
              <div className="flex items-start gap-3">
                <MapPin className="w-5 h-5 text-terracotta-600 shrink-0" />
                <div>
                  <p className="font-bold text-terracotta-950">Centros de Operaciones</p>
                  <p>Tehuacán, Puebla • Huajuapan de León, Oaxaca</p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Mail className="w-5 h-5 text-terracotta-600 shrink-0" />
                <div>
                  <p className="font-bold text-terracotta-950">Correo Electrónico</p>
                  <p className="lowercase">fdavila15nov@gmail.com</p>
                </div>
              </div>
            </div>

            {/* Redes sociales section */}
            <div className="space-y-4">
              <h4 className="font-serif text-lg text-terracotta-950 font-semibold">Nuestras Redes Sociales</h4>
              <p className="font-sans text-xs text-stone-550">
                Sigue nuestras historias diarias de cosecha, filtrado y embotellado manual.
              </p>
              
              <div className="flex flex-wrap gap-4 pt-1">
                <a
                  href="https://instagram.com/dafma.mezcal"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-3 bg-white border border-terracotta-100 hover:border-terracotta-300 hover:text-terracotta-700 text-stone-700 rounded-xl transition-all duration-300 shadow-sm"
                  aria-label="Instagram DAFMA"
                >
                  <Instagram className="w-5 h-5 text-terracotta-600" />
                  <span className="font-sans text-xs font-semibold tracking-wider">@dafma.mezcal</span>
                </a>

                <a
                  href="https://tiktok.com/@dafma.mezcal"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-3 bg-white border border-terracotta-100 hover:border-terracotta-300 hover:text-terracotta-700 text-stone-700 rounded-xl transition-all duration-300 shadow-sm"
                  aria-label="TikTok DAFMA"
                >
                  <TikTokIcon />
                  <span className="font-sans text-xs font-semibold tracking-wider">@dafma.mezcal</span>
                </a>

                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-2 p-3 bg-white border border-terracotta-100 hover:border-terracotta-300 hover:text-terracotta-700 text-stone-700 rounded-xl transition-all duration-300 shadow-sm"
                  aria-label="Facebook DAFMA"
                >
                  <Facebook className="w-5 h-5 text-terracotta-600" />
                  <span className="font-sans text-xs font-semibold tracking-wider">DAFMA Curados</span>
                </a>
              </div>
            </div>
          </div>

          {/* Form Column */}
          <div className="lg:col-span-7">
            <div className="p-6 sm:p-10 rounded-3xl bg-white border border-terracotta-150 shadow-md relative">
              <h3 className="font-serif text-2xl text-terracotta-950 font-bold mb-2">Escríbenos tu Mensaje</h3>
              <p className="font-sans text-xs sm:text-sm text-stone-500 mb-6 leading-relaxed">
                ¿Deseas realizar una cotización para eventos, catas guiadas o envíos a otras ciudades? Escríbenos y nos pondremos en contacto en menos de 24 horas.
              </p>

              <form onSubmit={handleSubmit} className="space-y-5">
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-stone-400">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    name="nombre"
                    required
                    placeholder="Tu nombre completo"
                    value={formData.nombre}
                    onChange={handleInputChange}
                    className="w-full bg-stone-50/50 border border-stone-200 focus:border-terracotta-600 rounded-xl py-3.5 pl-11 pr-4 text-sm text-stone-900 placeholder-stone-400 outline-none transition-colors"
                  />
                </div>

                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-4 text-stone-400">
                    <Mail className="w-4 h-4" />
                  </span>
                  <input
                    type="email"
                    name="email"
                    required
                    placeholder="Tu correo electrónico"
                    value={formData.email}
                    onChange={handleInputChange}
                    className="w-full bg-stone-50/50 border border-stone-200 focus:border-terracotta-600 rounded-xl py-3.5 pl-11 pr-4 text-sm text-stone-900 placeholder-stone-400 outline-none transition-colors"
                  />
                </div>

                <div className="relative">
                  <span className="absolute top-3.5 left-0 flex items-start pl-4 text-stone-400">
                    <MessageSquare className="w-4 h-4" />
                  </span>
                  <textarea
                    name="mensaje"
                    required
                    rows={4}
                    placeholder="Escribe tu consulta"
                    value={formData.mensaje}
                    onChange={handleInputChange}
                    className="w-full bg-stone-50/50 border border-stone-200 focus:border-terracotta-600 rounded-xl py-3.5 pl-11 pr-4 text-sm text-stone-900 placeholder-stone-400 outline-none transition-colors resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full flex items-center justify-center gap-2 bg-gradient-to-r from-terracotta-700 to-terracotta-800 hover:from-terracotta-600 hover:to-terracotta-700 text-white text-xs font-bold tracking-wider uppercase py-4 rounded-xl shadow-md cursor-pointer transition-colors"
                >
                  {isSubmitting ? (
                    <span className="animate-spin h-4 w-4 border-2 border-white border-t-transparent rounded-full" />
                  ) : (
                    <>
                      <Send className="w-4 h-4" />
                      <span>Enviar Formulario</span>
                    </>
                  )}
                </button>
              </form>

              {/* Alert Feedback messaging */}
              <AnimatePresence>
                {isSuccess && (
                  <motion.div
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: 10 }}
                    className="mt-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 animate-fade-in"
                  >
                    <div className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0" />
                      <div className="text-left">
                        <p className="font-serif font-bold text-stone-900 text-sm">¡Mensaje Recibido!</p>
                        <p className="font-sans text-xs text-stone-500">Gracias, procesaremos tu cotización de inmediato.</p>
                      </div>
                    </div>
                    
                    {/* Backup dynamic checkout helpers */}
                    <div className="flex gap-2 text-xs font-mono">
                      <a
                        href={mailtoLink}
                        className="font-bold uppercase tracking-wider text-terracotta-700 hover:underline"
                      >
                        Enviar por Email
                      </a>
                      <span className="text-stone-300">|</span>
                      <a
                        href={`https://wa.me/525620654031?text=${encodeURIComponent(formData.mensaje)}`}
                        target="_blank"
                        rel="noopener noreferrer"
                        className="font-bold uppercase tracking-wider text-emerald-700 hover:underline flex items-center gap-1"
                      >
                        <MessageCircle className="w-3 h-3" /> Enviar por WhatsApp
                      </a>
                    </div>
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </div>

        </div>

        {/* Footer legalities and credits */}
        <div className="pt-12 flex flex-col md:flex-row justify-between items-center gap-6 text-xs text-stone-500 font-sans">
          <div className="flex items-center gap-1.5">
            <p>© {new Date().getFullYear()} DAFMA Mezcal Curados. Todos los derechos reservados.</p>
          </div>

          <div className="flex items-center gap-6 font-medium">
            <a href="#inicio" className="hover:text-terracotta-700 transition-colors">Aviso de Privacidad</a>
            <a href="#inicio" className="hover:text-terracotta-700 transition-colors">Términos del Servicio</a>
            <button
              onClick={scrollToTop}
              className="flex items-center gap-1.5 p-2 bg-white border border-stone-200 hover:border-terracotta-600 hover:text-terracotta-700 text-stone-700 rounded-lg transition-colors group cursor-pointer"
              aria-label="Subir arriba"
            >
              <span>Subir</span>
              <ArrowUp className="w-3.5 h-3.5 group-hover:-translate-y-0.5 transition-transform" />
            </button>
          </div>
        </div>

      </div>
    </footer>
  );
}

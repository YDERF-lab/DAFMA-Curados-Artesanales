import React from "react";
import { motion } from "motion/react";
import { ArrowRight, MessageCircle, Flame, Star, ShieldCheck } from "lucide-react";
import { IMAGES } from "../data";

export default function Hero() {
  return (
    <section
      id="inicio"
      className="relative min-h-screen flex items-center justify-center overflow-hidden bg-[#faf7f2] pt-16"
    >
      {/* Background Image with Dark Vignette & Parallax feel */}
      <div className="absolute inset-0 z-0">
        <img
          src={IMAGES.heroBg}
          alt="Artesanal Mezcal Agave Background"
          className="w-full h-full object-cover scale-105 filter brightness-65 contrast-95 opacity-55 saturate-75"
          referrerPolicy="no-referrer"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-[#fdfbf7]/70 via-[#f9f6f2]/90 to-[#faf7f2]" />
        {/* Mexican Traditional Grid Pattern overlay */}
        <div className="absolute inset-0 mexican-pattern mix-blend-overlay opacity-5" />
      </div>

      {/* Content Container */}
      <div className="relative z-10 w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 text-center flex flex-col items-center justify-center">
        {/* Small badge */}
        <motion.div
          initial={{ opacity: 0, y: 15 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          className="inline-flex items-center gap-1.5 px-4 py-1.5 rounded-full bg-terracotta-50 border border-terracotta-200 text-terracotta-800 hover:border-terracotta-300 transition-colors mb-6 text-xs font-semibold tracking-widest uppercase font-mono"
        >
          <Flame className="w-3.5 h-3.5 text-terracotta-600 animate-pulse" />
          <span>Sabor Ancestral • Edición Limitada</span>
        </motion.div>

        {/* Brand Name display */}
        <motion.h2
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.1 }}
          className="font-display text-4xl sm:text-6xl md:text-8xl font-black text-terracotta-900 tracking-[0.25em] mb-1 text-glow select-none"
        >
          DAFMA
        </motion.h2>

        <motion.div
          initial={{ opacity: 0, width: 0 }}
          animate={{ opacity: 1, width: 140 }}
          transition={{ duration: 0.8, delay: 0.3 }}
          className="h-[2px] bg-gradient-to-r from-transparent via-amber-gold to-transparent mb-6"
        />

        {/* Hero Title */}
        <motion.h1
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.2 }}
          className="font-serif text-3xl sm:text-5xl md:text-6xl font-bold text-terracotta-950 tracking-tight leading-tight max-w-4xl"
        >
          Tradición, sabor y cultura mexicana en <span className="text-transparent bg-clip-text bg-gradient-to-r from-terracotta-700 via-brand-amber to-terracotta-600 font-serif italic font-normal">cada botella</span>
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.35 }}
          className="font-sans text-base sm:text-lg text-stone-700 max-w-2xl mt-6 leading-relaxed font-medium"
        >
          Curados artesanales de mezcal elaborados con ingredientes 100% naturales, cosechados y madurados con respeto absoluto al legado de Tehuacán y Huajuapan de León.
        </motion.p>

        {/* Action CTAs */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, delay: 0.5 }}
          className="flex flex-col sm:flex-row gap-4 mt-10 w-full sm:w-auto"
        >
          <a
            href="#productos"
            className="flex items-center justify-center gap-2 bg-gradient-to-r from-terracotta-700 to-terracotta-800 hover:from-terracotta-600 hover:to-terracotta-700 text-white text-sm font-bold tracking-widest uppercase px-8 py-4 rounded-xl border border-terracotta-650 shadow-lg hover:shadow-terracotta-800/30 transition-all duration-300 group"
          >
            <span>Descubre nuestros curados</span>
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </a>

          <a
            href="https://wa.me/525620654031?text=Hola%2C%20vi%20sus%20curados%20artesanales%20en%20la%20web%20y%20quiero%20hacer%20un%20pedido."
            target="_blank"
            rel="noopener noreferrer"
            className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold tracking-widest uppercase px-8 py-4 rounded-xl border border-emerald-500/50 hover:border-emerald-400 shadow-lg hover:shadow-emerald-900/30 transition-all duration-300"
          >
            <MessageCircle className="w-5 h-5 text-emerald-100" />
            <span>Compra por WhatsApp</span>
          </a>
        </motion.div>

        {/* Key Features Line */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="grid grid-cols-2 md:grid-cols-3 gap-6 md:gap-12 mt-16 pt-10 border-t border-terracotta-200/60 w-full max-w-4xl text-left"
        >
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-white border border-terracotta-100 shadow-sm text-terracotta-700">
              <Star className="w-5 h-5" />
            </div>
            <div>
              <p className="font-mono text-xs text-terracotta-650 uppercase tracking-wider font-semibold">Materia Prima</p>
              <h3 className="font-serif text-lg text-terracotta-950 font-bold">Mezcal Espadín 100%</h3>
            </div>
          </div>

          <div className="flex items-start gap-3">
            <div className="p-2 rounded-lg bg-white border border-terracotta-100 shadow-sm text-terracotta-700">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <p className="font-mono text-xs text-terracotta-650 uppercase tracking-wider font-semibold">100% Organico</p>
              <h3 className="font-serif text-lg text-terracotta-950 font-bold">Frutas Naturales</h3>
            </div>
          </div>

          <div className="flex items-start gap-3 col-span-2 md:col-span-1">
            <div className="p-2 rounded-lg bg-white border border-terracotta-100 shadow-sm text-terracotta-700">
              <Flame className="w-5 h-5" />
            </div>
            <div>
              <p className="font-mono text-xs text-terracotta-650 uppercase tracking-wider font-semibold">Elaboración</p>
              <h3 className="font-serif text-lg text-terracotta-950 font-bold">Lotes Numerados</h3>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Decorative Traditional Border Bottom */}
      <div className="absolute bottom-0 left-0 w-full">
        <div className="mexican-border-top" />
      </div>
    </section>
  );
}

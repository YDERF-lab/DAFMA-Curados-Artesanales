import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { MessageCircle, Sprout, Coins, Leaf, Info, Star, ChevronRight } from "lucide-react";
import { PRODUCTS } from "../data";
import { Product } from "../types";

export default function Products() {
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [activeTabs, setActiveTabs] = useState<Record<string, "desc" | "ing" | "notes">>({
    "nanche-dorado": "desc",
    "costa-blanca": "desc",
    "fuego-tamarindo": "desc"
  });

  const handleTabChange = (productId: string, tab: "desc" | "ing" | "notes") => {
    setActiveTabs(prev => ({
      ...prev,
      [productId]: tab
    }));
  };

  return (
    <section id="productos" className="relative py-24 sm:py-32 bg-[#faf7f2] overflow-hidden">
      {/* Decorative Traditional Border Top */}
      <div className="absolute top-0 left-0 w-full">
        <div className="mexican-border-top" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <span className="font-mono text-xs text-terracotta-600 font-bold tracking-[0.2em] uppercase block">
            Nuestra Colección Premium
          </span>
          <h2 className="font-display text-3xl sm:text-5xl text-terracotta-950 font-black tracking-tight">
            Los Curados de <span className="text-terracotta-750 font-serif italic font-normal">la Casa DAFMA</span>
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-terracotta-700 to-amber-gold mx-auto rounded" />
          <p className="font-sans text-sm sm:text-base text-stone-600">
            Macerados pacientemente entre 7 y 15 días con mezcal Espadín oaxaqueño auténtico y frutas cosechadas directamente por pequeños productores mixtecos. Una experiencia organoléptica única.
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-stretch">
          {PRODUCTS.map((prod, idx) => {
            const currentTab = activeTabs[prod.id] || "desc";

            return (
              <motion.div
                key={prod.id}
                id={`product-${prod.id}`}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.6, delay: idx * 0.2 }}
                className="flex flex-col rounded-3xl bg-white border border-terracotta-100 hover:border-terracotta-300 overflow-hidden shadow-md hover:shadow-xl transition-all duration-300 group"
              >
                {/* Visual Area */}
                <div className="relative h-72 sm:h-80 overflow-hidden bg-[#faf7f2] flex items-center justify-center p-4">
                  
                  {/* Subtle Background Radial Glow */}
                  <div className="absolute inset-0 bg-radial-gradient from-amber-700/10 to-transparent" />

                  {/* Generated luxurious product photo */}
                  <img
                    src={prod.image}
                    alt={prod.name}
                    className="w-full h-full object-cover rounded-2xl group-hover:scale-105 transition-transform duration-700 select-none"
                    referrerPolicy="no-referrer"
                  />

                  {/* Floating Price Badge */}
                  <div className="absolute bottom-4 right-4 bg-white/95 border border-terracotta-200 hover:border-terracotta-400 px-4 py-2 rounded-xl backdrop-blur-md text-terracotta-800 font-bold font-mono text-sm tracking-wide shadow-md transition-colors">
                    Precio Sugerido: {prod.price}
                  </div>

                  {/* Brand signature overlay */}
                  <div className="absolute top-4 left-4 bg-terracotta-700 text-white text-[10px] font-mono uppercase tracking-[0.2em] px-3 py-1 rounded-full font-bold">
                    Artesanal • Oaxaca
                  </div>
                </div>

                {/* Info and Navigation Tabs */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between space-y-6">
                  <div className="space-y-4">
                    
                    {/* Header title */}
                    <div className="space-y-1">
                      <h3 className="font-serif text-2xl sm:text-3xl text-stone-900 font-bold group-hover:text-terracotta-700 transition-colors">
                        {prod.name}
                      </h3>
                      <p className="font-sans text-xs italic text-terracotta-750 font-bold tracking-wide">
                        {prod.tagline}
                      </p>
                    </div>

                    {/* Interactive Tab Switcher */}
                    <div className="flex border-b border-stone-150 pb-2 text-xs font-semibold uppercase tracking-wider">
                      <button
                        onClick={() => handleTabChange(prod.id, "desc")}
                        className={`flex-1 pb-2 transition-colors border-b-2 text-center cursor-pointer ${
                          currentTab === "desc"
                            ? "border-terracotta-600 text-terracotta-700 font-bold"
                            : "border-transparent text-stone-500 hover:text-terracotta-700"
                        }`}
                      >
                        Descripción
                      </button>
                      <button
                        onClick={() => handleTabChange(prod.id, "ing")}
                        className={`flex-1 pb-2 transition-colors border-b-2 text-center cursor-pointer ${
                          currentTab === "ing"
                            ? "border-terracotta-600 text-terracotta-700 font-bold"
                            : "border-transparent text-stone-500 hover:text-terracotta-700"
                        }`}
                      >
                        Ingredientes
                      </button>
                      <button
                        onClick={() => handleTabChange(prod.id, "notes")}
                        className={`flex-1 pb-2 transition-colors border-b-2 text-center cursor-pointer ${
                          currentTab === "notes"
                            ? "border-terracotta-600 text-terracotta-700 font-bold"
                            : "border-transparent text-stone-500 hover:text-terracotta-700"
                        }`}
                      >
                        Notas Cata
                      </button>
                    </div>

                    {/* Tab Switcher Content with animation */}
                    <div className="min-h-[110px] py-1 font-sans text-sm text-stone-700 leading-relaxed">
                      <AnimatePresence mode="wait">
                        {currentTab === "desc" && (
                          <motion.div
                            key="desc"
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 10 }}
                            transition={{ duration: 0.15 }}
                          >
                            <p className="text-stone-700 font-sans">{prod.description}</p>
                          </motion.div>
                        )}
 
                        {currentTab === "ing" && (
                          <motion.div
                            key="ing"
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 10 }}
                            transition={{ duration: 0.15 }}
                            className="space-y-2"
                          >
                            <p className="text-xs text-stone-500 mb-2 font-mono uppercase tracking-[0.1em] flex items-center gap-1.5 font-bold">
                              <Leaf className="w-3.5 h-3.5 text-emerald-600" />
                              Ingredientes 100% integrales:
                            </p>
                            <div className="grid grid-cols-1 gap-1.5">
                              {prod.ingredients.map((ing) => (
                                <div key={ing} className="flex items-center gap-2 text-xs text-stone-750 bg-terracotta-50/50 py-1 px-2.5 rounded-lg border border-terracotta-100/60">
                                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                                  <span>{ing}</span>
                                </div>
                              ))}
                            </div>
                          </motion.div>
                        )}
 
                        {currentTab === "notes" && (
                          <motion.div
                            key="notes"
                            initial={{ opacity: 0, x: -10 }}
                            animate={{ opacity: 1, x: 0 }}
                            exit={{ opacity: 0, x: 10 }}
                            transition={{ duration: 0.15 }}
                          >
                            <p className="text-stone-850 font-serif italic text-base border-l-2 border-terracotta-600 pl-3">
                              "{prod.notes}"
                            </p>
                            <div className="mt-2.5 flex gap-1 items-center">
                              {[...Array(5)].map((_, i) => (
                                <Star key={i} className="w-3.5 h-3.5 fill-amber-gold text-amber-gold" />
                              ))}
                              <span className="text-[10px] font-mono text-stone-500 tracking-wider uppercase ml-1.5">Calidad Suprema</span>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </div>
 
                  </div>
 
                  {/* Primary Call to Action Button */}
                  <div className="pt-4 border-t border-stone-150 space-y-3">
                    <a
                      href={`https://wa.me/525620654031?text=${encodeURIComponent(prod.whatsappMessage)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold tracking-wider uppercase py-3.5 px-5 rounded-xl border border-emerald-500/30 hover:border-emerald-400/50 shadow-md hover:shadow-emerald-990/25 transition-all duration-300 group"
                    >
                      <MessageCircle className="w-4 h-4 fill-emerald-100/10 text-emerald-100" />
                      <span>Pedir por WhatsApp</span>
                      <ChevronRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                    </a>
                    
                    <button
                      onClick={() => setSelectedProduct(prod)}
                      className="w-full text-center text-xs font-mono text-stone-500 hover:text-terracotta-800 transition-colors block underline underline-offset-4 cursor-pointer"
                    >
                      Ver especificaciones completas
                    </button>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

             {/* Detailed Spec Modal */}
        <AnimatePresence>
          {selectedProduct && (
            <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-sm">
              <motion.div
                initial={{ scale: 0.95, opacity: 0 }}
                animate={{ scale: 1, opacity: 1 }}
                exit={{ scale: 0.95, opacity: 0 }}
                className="bg-white border border-terracotta-200 rounded-3xl p-6 sm:p-10 max-w-2xl w-full relative shadow-2xl space-y-6"
              >
                <div className="flex justify-between items-start">
                  <div>
                    <p className="font-mono text-xs uppercase text-terracotta-700 tracking-widest font-bold">{selectedProduct.tagline}</p>
                    <h3 className="font-serif text-3xl text-terracotta-950 font-bold">{selectedProduct.name}</h3>
                  </div>
                  <button
                    onClick={() => setSelectedProduct(null)}
                    className="p-1 px-3 text-sm font-mono text-stone-500 hover:text-terracotta-850 border border-stone-200 hover:border-terracotta-300 rounded-lg transition-colors cursor-pointer"
                  >
                    cerrar
                  </button>
                </div>
 
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 items-center">
                  <div className="relative rounded-2xl overflow-hidden border border-stone-150 shadow-md bg-[#faf7f2] aspect-square">
                    <img
                      src={selectedProduct.image}
                      alt={selectedProduct.name}
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <div className="space-y-4">
                    <div className="p-3.5 bg-terracotta-50/70 rounded-xl border border-terracotta-100/60">
                      <p className="font-mono text-[10px] text-stone-500 uppercase tracking-widest font-bold">Grado alcohólico</p>
                      <p className="font-serif text-sm text-terracotta-900 font-medium">35% Alc. Vol. de pureza armonizada</p>
                    </div>
                    <div className="p-3.5 bg-terracotta-50/70 rounded-xl border border-terracotta-100/60">
                      <p className="font-mono text-[10px] text-stone-500 uppercase tracking-widest font-bold">Maceración</p>
                      <p className="font-serif text-sm text-terracotta-900 font-medium">De 7 a 15 días en vidrio templado</p>
                    </div>
                    <div className="p-3.5 bg-terracotta-50/70 rounded-xl border border-terracotta-100/60">
                      <p className="font-mono text-[10px] text-stone-500 uppercase tracking-widest font-bold">Origen Mezcalero</p>
                      <p className="font-serif text-sm text-terracotta-900 font-medium">San Dionisio Ocotepec, Oaxaca</p>
                    </div>
                  </div>
                </div>
 
                <div className="space-y-2">
                  <h4 className="font-serif text-lg text-terracotta-950 font-bold">Resumen de Cata de la casa:</h4>
                  <p className="font-sans text-sm text-stone-700 leading-relaxed bg-terracotta-50/30 p-4 rounded-xl border border-terracotta-100/55 font-medium">
                    {selectedProduct.notes} El curado artesanal respeta plenamente el cuerpo del Espadín nativo introduciendo un equilibrio de dulzura de fruta natural.
                  </p>
                </div>
 
                <div className="flex flex-col sm:flex-row gap-3 pt-4 border-t border-stone-150">
                  <a
                    href={`https://wa.me/525620654031?text=${encodeURIComponent(selectedProduct.whatsappMessage)}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold tracking-wider uppercase py-4 rounded-xl border border-emerald-500/50 shadow-md transition-colors"
                  >
                    <MessageCircle className="w-5 h-5" />
                    <span>Realizar Pedido Sugerido ({selectedProduct.price})</span>
                  </a>
                </div>
              </motion.div>
            </div>
          )}
        </AnimatePresence>

      </div>
    </section>
  );
}

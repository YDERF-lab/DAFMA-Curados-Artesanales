export interface Product {
  id: string;
  name: string;
  tagline: string;
  description: string;
  notes: string;
  price: string;
  ingredients: string[];
  image: string;
  whatsappMessage: string;
  accentColor: string;
}

export interface ProcessStep {
  stepNumber: number;
  title: string;
  description: string;
}

export interface ValueCard {
  title: string;
  description: string;
  icon: string;
}

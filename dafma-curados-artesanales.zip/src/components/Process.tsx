import React, { useState } from "react";
import { motion, AnimatePresence } from "motion/react";
import { PROCESS_STEPS } from "../data";
import { Flame, Clock, Calendar, ShieldAlert, Award, ArrowLeft, ArrowRight } from "lucide-react";

export default function Process() {
  const [activeStep, setActiveStep] = useState(0);

  const prevStep = () => {
    setActiveStep((prev) => (prev === 0 ? PROCESS_STEPS.length - 1 : prev - 1));
  };

  const nextStep = () => {
    setActiveStep((prev) => (prev === PROCESS_STEPS.length - 1 ? 0 : prev + 1));
  };

  return (
    <section id="proceso" className="relative py-24 sm:py-32 bg-[#faf7f2] overflow-hidden border-t border-stone-150">
      {/* Background patterns */}
      <div className="absolute inset-0 mexican-pattern mix-blend-color opacity-[0.03] pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="font-mono text-xs text-terracotta-600 font-bold tracking-[0.2em] uppercase block">
            El Arte del Curado
          </span>
          <h2 className="font-serif text-3xl sm:text-5xl text-terracotta-950 font-semibold tracking-tight">
            Nuestros 8 Pasos de <span className="text-terracotta-750 font-serif italic font-normal">Creación Ancestral</span>
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-terracotta-700 to-amber-gold mx-auto rounded" />
          <p className="font-sans text-sm text-stone-600">
            Descubre el viaje místico de cada gota de DAFMA Mezcal. Explicado meticulosamente paso a paso desde la colecta hasta tu mesa.
          </p>
        </div>

        {/* Highlight Certification Block banner */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 bg-white border border-terracotta-100 p-6 sm:p-8 rounded-2xl shadow-md max-w-4xl mx-auto mb-16 items-center">
          <div className="flex items-center gap-4">
            <div className="p-3.5 bg-terracotta-50 text-terracotta-700 border border-terracotta-150 rounded-xl">
              <Clock className="w-6 h-6" />
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase text-stone-500 font-bold tracking-wider">Tiempo de Maduración Celosa</p>
              <h3 className="font-serif text-xl sm:text-2xl text-terracotta-950 font-bold">7 – 15 Días Completos</h3>
              <p className="font-sans text-xs text-stone-600 mt-0.5">El tiempo que nuestra fruta descansa de forma natural en el mezcal oaxaqueño.</p>
            </div>
          </div>

          <div className="flex items-center gap-4 md:border-l md:border-stone-150 md:pl-8">
            <div className="p-3.5 bg-emerald-50 text-emerald-700 border border-emerald-100 rounded-xl">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase text-stone-500 font-bold tracking-wider">Producción Micro-Lotes Limitada</p>
              <h3 className="font-serif text-xl sm:text-2xl text-terracotta-950 font-bold">60 – 80 Botellas al Mes</h3>
              <p className="font-sans text-xs text-stone-600 mt-0.5">Controlamos cada botella de puño y letra garantizando un curado ultra premium.</p>
            </div>
          </div>
        </div>

        {/* Timeline Desktop & Tablet Staggered Visual Grid */}
        <div className="hidden lg:grid grid-cols-4 gap-8 mb-20">
          {PROCESS_STEPS.map((step, idx) => (
            <motion.div
              key={step.stepNumber}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              onClick={() => setActiveStep(idx)}
              className={`relative cursor-pointer group p-6 rounded-2xl border transition-all duration-300 ${
                activeStep === idx
                  ? "bg-white border-terracotta-400 shadow-md scale-102"
                  : "bg-white/70 border-terracotta-100/70 hover:border-terracotta-300 hover:shadow-sm"
              }`}
            >
              <div className="absolute top-4 right-4 font-mono font-black text-3xl opacity-10 text-stone-900">
                0{step.stepNumber}
              </div>

              <div className={`p-2.5 rounded-lg w-fit border mb-4 font-mono text-xs font-bold ${
                activeStep === idx
                  ? "bg-terracotta-50 text-terracotta-700 border-terracotta-200"
                  : "bg-stone-50 text-stone-500 border-stone-100"
              }`}>
                Paso 0{step.stepNumber}
              </div>

              <h3 className="font-serif text-lg text-terracotta-950 font-bold mb-2 group-hover:text-terracotta-700 transition-colors">
                {step.title}
              </h3>

              <p className="font-sans text-xs text-stone-600 leading-relaxed line-clamp-3">
                {step.description}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Carousel for Mobile & Main Viewer */}
        <div className="relative max-w-3xl mx-auto rounded-3xl bg-white border border-terracotta-150 p-6 sm:p-10 shadow-lg">
          <div className="flex justify-between items-center mb-6">
            <span className="font-mono text-xs text-terracotta-700 tracking-widest font-bold uppercase">
              Proceso Detallado
            </span>
            <span className="font-mono text-sm text-stone-400 font-bold">
              {activeStep + 1} de {PROCESS_STEPS.length}
            </span>
          </div>

          <div className="min-h-[160px] flex flex-col justify-center space-y-4">
            <AnimatePresence mode="wait">
              <motion.div
                key={activeStep}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.25 }}
                className="space-y-4"
              >
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-xl bg-terracotta-700 font-serif font-black text-lg text-white flex items-center justify-center border border-terracotta-500">
                    {PROCESS_STEPS[activeStep].stepNumber}
                  </div>
                  <h3 className="font-serif text-2xl text-terracotta-950 font-bold tracking-tight">
                    {PROCESS_STEPS[activeStep].title}
                  </h3>
                </div>

                <p className="font-sans text-base text-stone-700 leading-relaxed pl-1">
                  {PROCESS_STEPS[activeStep].description}
                </p>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Navigation controls */}
          <div className="flex justify-between items-center mt-8 pt-6 border-t border-stone-150">
            <button
              onClick={prevStep}
              className="flex items-center gap-2 p-2 px-4 rounded-xl border border-stone-200 hover:border-terracotta-600 hover:text-terracotta-700 text-stone-700 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" />
              <span>Anterior</span>
            </button>

            {/* Micro indicators dots */}
            <div className="flex gap-1.5">
              {PROCESS_STEPS.map((_, i) => (
                <button
                  key={i}
                  onClick={() => setActiveStep(i)}
                  className={`w-1.5 h-1.5 rounded-full transition-all duration-300 ${
                    activeStep === i ? "w-5 bg-terracotta-600" : "bg-stone-200 hover:bg-stone-300"
                  }`}
                  aria-label={`Go to step ${i + 1}`}
                />
              ))}
            </div>

            <button
              onClick={nextStep}
              className="flex items-center gap-2 p-2 px-4 rounded-xl border border-stone-200 hover:border-terracotta-600 hover:text-terracotta-700 text-stone-700 text-xs font-mono uppercase tracking-wider transition-colors cursor-pointer"
            >
              <span>Siguiente</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>
    </section>
  );
}

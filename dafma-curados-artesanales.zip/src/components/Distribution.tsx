import React from "react";
import { motion } from "motion/react";
import { Store, Palmtree, Ticket, Send, ShieldCheck, Heart } from "lucide-react";
import { CHANNELS } from "../data";

export default function Distribution() {
  const getIcon = (category: string) => {
    switch (category) {
      case "Puntos de venta":
        return <Store className="w-6 h-6 text-amber-gold" />;
      case "Eventos":
        return <Palmtree className="w-6 h-6 text-amber-gold" />;
      case "Cultura":
        return <Ticket className="w-6 h-6 text-amber-gold" />;
      default:
        return <Send className="w-6 h-6 text-amber-gold" />;
    }
  };

  return (
    <section id="canales" className="relative py-24 sm:py-32 bg-[#120c08] overflow-hidden">
      {/* Background traditional watermarks */}
      <div className="absolute inset-0 mexican-pattern mix-blend-color opacity-3 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <span className="font-mono text-xs text-terracotta-600 font-bold tracking-[0.2em] uppercase block">
            Distribución & Alianzas
          </span>
          <h2 className="font-serif text-3xl sm:text-5xl text-white font-semibold tracking-tight">
            ¿Dónde conseguir el sabor de <span className="text-amber-gold font-serif italic font-normal">DAFMA?</span>
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-terracotta-700 to-amber-gold mx-auto rounded" />
          <p className="font-sans text-sm text-gray-400">
            Nuestros lotes de curados artesanales se distribuyen selectamente en la región Mixteca y de manera directa a todo el país vía digital.
          </p>
        </div>

        {/* Distribution Grid list */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {CHANNELS.map((ch, idx) => (
            <motion.div
              key={ch.title}
              initial={{ opacity: 0, x: idx % 2 === 0 ? -30 : 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true, margin: "-50px" }}
              transition={{ duration: 0.6 }}
              className="flex items-start gap-4 p-6 sm:p-8 rounded-3xl bg-[#0d0906] border border-white/5 hover:border-terracotta-700/30 transition-all duration-300"
            >
              {/* Category Icon indicator */}
              <div className="p-3 bg-white/5 border border-white/10 rounded-2xl shrink-0">
                {getIcon(ch.category)}
              </div>

              {/* Text items */}
              <div className="space-y-2">
                <span className="font-mono text-[10px] text-terracotta-300 uppercase tracking-widest font-semibold block">
                  {ch.category}
                </span>
                
                <h3 className="font-serif text-xl text-white font-bold">
                  {ch.title}
                </h3>
                
                <p className="font-sans text-xs sm:text-sm text-gray-400 leading-relaxed">
                  {ch.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Region Map Concept representation */}
        <div className="mt-20 p-8 sm:p-12 rounded-3xl bg-clay-950 border border-white/5 text-center max-w-3xl mx-auto relative overflow-hidden">
          {/* Subtle graphic circular glow representing geographic coordinates */}
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-terracotta-700/5 blur-3xl pointer-events-none" />

          <div className="relative z-10 space-y-6">
            <span className="font-mono text-xs text-amber-gold uppercase tracking-[0.25em] font-semibold">Región Mixteca Orgullosa</span>
            <h3 className="font-serif text-2xl sm:text-3xl text-white font-bold">Puntos Clave de Envío Inmediato</h3>
            <p className="font-sans text-sm text-gray-350 max-w-xl mx-auto leading-relaxed">
              Consolidamos despachos diarios desde nuestros centros de distribución manuales ubicados en <strong className="text-white">Tehuacán, Puebla (Col. Centro)</strong> y <strong className="text-white">Huajuapan de León, Oaxaca (Mercado Regional)</strong>. Hacemos envíos coordinados por paquetería express de primera línea.
            </p>
            <div className="flex gap-4 justify-center items-center font-mono text-xs text-gray-400 uppercase">
              <span className="flex items-center gap-1.5"><ShieldCheck className="w-4 h-4 text-emerald-500" /> Embalaje Seguro</span>
              <span className="w-1.5 h-1.5 rounded-full bg-gray-700" />
              <span className="flex items-center gap-1.5"><Heart className="w-4 h-4 text-red-500 fill-red-500" /> Mezcal 100% Genuino</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

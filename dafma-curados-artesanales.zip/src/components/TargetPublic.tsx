import React from "react";
import { motion } from "motion/react";
import { Sparkles, MapPin, Flame, Award, HeartHandshake, CheckCircle } from "lucide-react";
import { PUBLIC_SEGMENTS } from "../data";

const iconMap: Record<string, React.ReactNode> = {
  Sparkles: <Sparkles className="w-7 h-7 text-terracotta-600 animate-pulse" />,
  MapPin: <MapPin className="w-7 h-7 text-terracotta-600" />,
  Flame: <Flame className="w-7 h-7 text-terracotta-600" />,
  Award: <Award className="w-7 h-7 text-terracotta-600" />
};

export default function TargetPublic() {
  return (
    <section id="segmentacion" className="relative py-24 sm:py-32 bg-[#faf7f2] overflow-hidden border-t border-stone-150">
      {/* Decorative Border Line Top */}
      <div className="absolute top-0 left-0 w-full">
        <div className="mexican-border-top" />
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Block */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <span className="font-mono text-xs text-terracotta-600 font-bold tracking-[0.2em] uppercase block">
            Público y Segmentación
          </span>
          <h2 className="font-display text-3xl sm:text-5xl text-terracotta-950 font-black tracking-tight">
            ¿Para quién creamos <span className="text-terracotta-750 font-serif italic font-normal">cada Mezcal?</span>
          </h2>
          <div className="h-1 w-24 bg-gradient-to-r from-terracotta-700 to-amber-gold mx-auto rounded" />
          <p className="font-sans text-sm text-stone-600">
            Nuestros curados están pensados para paladares aventureros que aprecian el diseño, la tradición líquida mexicana, y buscan una alternativa de sabor premium.
          </p>
        </div>

        {/* Demographics Grid Row */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {PUBLIC_SEGMENTS.map((seg, idx) => (
            <motion.div
              key={seg.title}
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.12 }}
              className="relative p-6 sm:p-8 rounded-3xl bg-white border border-terracotta-100 hover:border-terracotta-300 transition-all duration-300 shadow-sm hover:shadow-md group"
            >
              {/* Card top ornament */}
              <div className="w-fit p-3 bg-terracotta-50/50 rounded-2xl border border-terracotta-100 mb-6 group-hover:bg-terracotta-50 transition-colors">
                {iconMap[seg.icon]}
              </div>

              <h3 className="font-serif text-xl text-terracotta-950 font-bold mb-3 group-hover:text-terracotta-700 transition-colors">
                {seg.title}
              </h3>

              <p className="font-sans text-xs sm:text-sm text-stone-600 leading-relaxed">
                {seg.description}
              </p>

              {/* Decorative side accent lines mimicking loom threads */}
              <div className="absolute top-8 right-8 flex gap-1 h-2">
                <span className="w-1 h-1 rounded-full bg-terracotta-600" />
                <span className="w-1 h-1 rounded-full bg-amber-gold" />
                <span className="w-1 h-1 rounded-full bg-emerald-600" />
              </div>
            </motion.div>
          ))}
        </div>

        {/* Customer Satisfaction Value Banner */}
        <div className="mt-20 p-8 sm:p-10 rounded-3xl bg-white border border-terracotta-150 max-w-4xl mx-auto flex flex-col md:flex-row items-center gap-8 shadow-md">
          <div className="p-4 bg-terracotta-50 text-terracotta-700 rounded-full shrink-0 border border-terracotta-100">
            <HeartHandshake className="w-10 h-10" />
          </div>
          <div className="space-y-3 text-center md:text-left">
            <h4 className="font-serif text-xl sm:text-2xl text-terracotta-950 font-bold">Unión, tradición e identidad campesina</h4>
            <p className="font-sans text-sm text-stone-700 leading-relaxed">
              Trabajamos con el corazón de la mixteca. Fomentamos el comercio solidario y justo con artesanos, recolectores locales y agricultores de nanche, piña y tamarindo orgánicos. Cada copa apoya directamente la economía de Tehuacán y Oaxaca.
            </p>
            <div className="flex flex-wrap justify-center md:justify-start gap-4 pt-2 text-xs font-mono text-terracotta-800 font-bold uppercase">
              <span className="flex items-center gap-1"><CheckCircle className="w-4 h-4 text-emerald-600" /> 100% natural, sin químicos</span>
              <span className="flex items-center gap-1"><CheckCircle className="w-4 h-4 text-emerald-600" /> Trato y comercio justo</span>
            </div>
          </div>
        </div>

      </div>
    </section>
  );
}

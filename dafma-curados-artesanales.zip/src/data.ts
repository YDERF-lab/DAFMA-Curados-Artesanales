import { Product, ProcessStep, ValueCard } from "./types";

export const IMAGES = {
  heroBg: "/src/assets/images/three_bottles_collection_1780542158262.png",
  nancheDorado: "/src/assets/images/nanche_dorado_real_1780542120793.png",
  costaBlanca: "/src/assets/images/costa_blanca_real_1780542146571.png",
  fuegoTamarindo: "/src/assets/images/fuego_tamarindo_real_1780542134610.png",
  brandLogo: "/src/assets/images/dafma_brand_logo_1780542108617.png"
};

export const PRODUCTS: Product[] = [
  {
    id: "nanche-dorado",
    name: "Nanche Dorado",
    tagline: "El oro de nuestros campos",
    description: "Curado tradicional dulce y afrutado que captura el alma festiva del nanche. Macerado lentamente para lograr un equilibrio sublime con el mezcal.",
    notes: "Notas intensas de fruta madura, final amielado con sutil retrogusto terroso y ahumado.",
    price: "$420 MXN",
    ingredients: [
      "Nanches dorados seleccionados",
      "Mezcal Espadín artesanal",
      "Jarabe reposado de agave",
      "Pizca de canela fina"
    ],
    image: IMAGES.nancheDorado,
    whatsappMessage: "¡Hola! Me gustaría pedir una botella del delicioso y artesanal Curado Nanche Dorado ($420 MXN). ¿Me podrían ayudar?",
    accentColor: "from-amber-400 to-amber-600"
  },
  {
    id: "costa-blanca",
    name: "Costa Blanca",
    tagline: "La suavidad de la Mixteca y la Costa",
    description: "Una mezcla exótica, cremosa y refrescante. Combina notas tropicales de coco y piña fresca con la potencia del destilado ancestral.",
    notes: "Textura tersa y láctica, notas dulces de crema de coco balanceadas con acidez sutil de piña natural.",
    price: "$450 MXN",
    ingredients: [
      "Piña dulce madura",
      "Crema de coco de primera prensa",
      "Leche evaporada deslactosada",
      "Mezcal Espadín artesanal"
    ],
    image: IMAGES.costaBlanca,
    whatsappMessage: "¡Hola! Estoy muy interesado en adquirir una botella del cremoso Curado Costa Blanca ($450 MXN). ¿Tienen disponibilidad?",
    accentColor: "from-slate-100 to-amber-100/50"
  },
  {
    id: "fuego-tamarindo",
    name: "Fuego Tamarindo",
    tagline: "El balance perfecto entre dulce y picante",
    description: "Un maridaje inolvidable que despierta todos los sentidos. La pulpa natural del tamarindo se funde con chiles seleccionados y la calidez del mezcal.",
    notes: "Agridulce, picante moderado en garganta, final ahumado y salino sumamente refrescante.",
    price: "$390 MXN",
    ingredients: [
      "Pulpa artesanal de tamarindo silvestre",
      "Mezcal Espadín artesanal",
      "Mezcla secreta de chiles en polvo",
      "Sal de gusano de agave de Oaxaca"
    ],
    image: IMAGES.fuegoTamarindo,
    whatsappMessage: "¡Hola! Quisiera ordenar el audaz Curado Fuego Tamarindo ($390 MXN). ¿Hacen envíos directos?",
    accentColor: "from-amber-800 to-red-950"
  }
];

export const PROCESS_STEPS: ProcessStep[] = [
  {
    stepNumber: 1,
    title: "Selección del Mezcal Artesanal",
    description: "Seleccionamos mezcal Espadín 100% de agave producido en palenques tradicionales de Oaxaca, garantizando su autenticidad y graduación óptima."
  },
  {
    stepNumber: 2,
    title: "Cosecha e Ingredientes Frescos",
    description: "Solo utilizamos frutas naturales adquiridas directamente de productores locales de Tehuacán y la Mixteca: nanches maduros, piñas jugosas y tamarindos auténticos."
  },
  {
    stepNumber: 3,
    title: "Lavado e Higienización Quirúrgica",
    description: "Tratamos cada fruta con rigurosa limpieza y desinfección, asegurando que mantengan su frescura organoléptica intacta."
  },
  {
    stepNumber: 4,
    title: "Maceración Prolongada",
    description: "La fruta descansa en mezcal dentro de recipientes herméticos por un lapso óptimo de 7 a 15 días, el punto exacto donde la infusión absorbe las notas del destilado."
  },
  {
    stepNumber: 5,
    title: "Elaboración de Fórmulas y Jarabe",
    description: "Incorporamos sutiles jarabes naturales y especias secretas para enriquecer el cuerpo del curado, sin opacar la presencia del mezcal."
  },
  {
    stepNumber: 6,
    title: "Filtración en Tres Pasos",
    description: "Clarificamos el curado a mano a través de filtros de tela fina para retener impurezas y semillas de la fruta, logrando un cuerpo limpio pero con rica textura."
  },
  {
    stepNumber: 7,
    title: "Embotellado en Lotes Numerados",
    description: "Llenamos cada botella manualmente. La producción es en lotes pequeños (60 a 80 botellas mensuales) para asegurar una calidad premium."
  },
  {
    stepNumber: 8,
    title: "Envase y Sellado de Garantía",
    description: "Sellamos cada botella herméticamente con cera o tapones naturales, lista para transportarse directamente a tu copa."
  }
];

export const VALUE_CARDS: ValueCard[] = [
  {
    title: "Nuestra Misión",
    description: "Compartir la rica tradición oaxaqueña e identidad mexicana a través de mezcales curados artesanales únicos. Elaborados con ingredientes 100% naturales, preservando el saber ancestral y fomentando el comercio justo con nuestros productores locales de Tehuacán y Huajuapan.",
    icon: "Compass"
  },
  {
    title: "Nuestra Visión",
    description: "Ser reconocidos nacional e internacionalmente como la marca líder de curados de mezcal artesanal de alta gama en la región Mixteca. Buscamos innovar constantemente en sabores sin perder el alma de la receta tradicional.",
    icon: "Eye"
  },
  {
    title: "Nuestros Valores",
    description: "Nuestras raíces guían cada paso. Creemos en el Respeto a la tierra, el Orgullo de nuestra herencia cultural, el Compromiso con la calidad excepcional y la Trasparencia en cada botella que elaboramos numéricamente.",
    icon: "Heart"
  }
];

export const PUBLIC_SEGMENTS = [
  {
    title: "Jóvenes de 18 a 35 años",
    description: "Amantes de los sabores novedosos, coctelería exótica y experiencias culturales auténticas para compartir en redes sociales.",
    icon: "Sparkles"
  },
  {
    title: "Turistas Nacionales y Extranjeros",
    description: "Viajeros en búsqueda de llevarse un pedazo líquido de la gran Mixteca y la tradición mágica de Oaxaca.",
    icon: "MapPin"
  },
  {
    title: "Consumidores de Mezcal y Destilados",
    description: "Paladares maduros que aprecian notas complejas, la fineza de la maceración manual y el valor de un destilado 100% artesanal.",
    icon: "Flame"
  },
  {
    title: "Nivel Socioeconómico (C+, C, D+)",
    description: "Personas que valoran productos premium y artesanales o buscan regalos especiales con diseño e historia detrás.",
    icon: "Award"
  }
];

export const CHANNELS = [
  {
    title: "Tiendas Físicas Autorizadas",
    description: "Encuentra nuestras botellas de edición limitada en boutiques regionales y puntos seleccionados de Tehuacán, Puebla y Huajuapan de León, Oaxaca.",
    category: "Puntos de venta"
  },
  {
    title: "Ferias Gastronómicas & Agropecuarias",
    description: "Participamos activamente en los pabellones gastronómicos más importantes de la Mixteca, ofreciendo catas guiadas e historias detrás de la marca.",
    category: "Eventos"
  },
  {
    title: "Eventos Culturales & Talleres",
    description: "Presentes en festivales culturales de Oaxaca y Puebla, en donde impartimos pláticas sobre la importancia del curado como tradición compartida.",
    category: "Cultura"
  },
  {
    title: "Venta Directa & Entrega Local",
    description: "Pedida directa con entrega personalizada y envíos coordinados por WhatsApp, asegurando que tu lote llegue fresco y seguro.",
    category: "Digital"
  }
];

import React, { useState, useEffect } from "react";
import { motion, AnimatePresence } from "motion/react";
import { Menu, X, MessageCircle, Instagram, Facebook } from "lucide-react";
import { IMAGES } from "../data";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { name: "Inicio", href: "#inicio" },
    { name: "Nosotros", href: "#nosotros" },
    { name: "Filosofía", href: "#filosofia" },
    { name: "Productos", href: "#productos" },
    { name: "Proceso", href: "#proceso" },
    { name: "Segmentación", href: "#segmentacion" },
    { name: "Canales", href: "#canales" },
    { name: "Contacto", href: "#contacto" },
  ];

  return (
    <>
      {/* Top micro-banner typical of luxury brands */}
      <div id="micro-banner" className="bg-terracotta-800 text-terracotta-100 text-xs py-1 px-4 text-center tracking-[0.25em] font-sans font-medium uppercase relative z-50">
        Edición Limitada • Mezcal Curado 100% Artesanal
      </div>

      <header
        id="navbar"
        className={`fixed top-7 left-0 right-0 z-40 mx-auto max-w-7xl px-4 sm:px-6 transition-all duration-300 ${
          isScrolled ? "top-2" : "top-7"
        }`}
      >
        <div
          className={`mx-auto rounded-2xl border transition-all duration-300 ${
            isScrolled
              ? "bg-white/95 backdrop-blur-md border-terracotta-200/80 shadow-lg"
              : "bg-white/80 backdrop-blur-sm border-terracotta-100/60 shadow-sm"
          }`}
        >
          <div className="flex items-center justify-between px-4 sm:px-6 h-18">
            {/* Logo area */}
            <div className="flex items-center gap-3">
              <a href="#inicio" className="flex items-center gap-2 group">
                <img
                  src={IMAGES.brandLogo}
                  alt="DAFMA Logo"
                  className="w-9 h-9 object-contain rounded-full border border-amber-gold/30 group-hover:border-amber-gold transition-colors"
                  referrerPolicy="no-referrer"
                />
                <span className="font-display text-2xl font-bold tracking-[0.2em] text-terracotta-900 group-hover:text-amber-gold transition-colors">
                  DAFMA
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-terracotta-600 group-hover:bg-amber-gold transition-colors animate-pulse" />
                <span className="font-serif text-xs italic tracking-widest text-terracotta-700 group-hover:text-amber-gold transition-colors uppercase hidden min-[400px]:inline font-medium">
                  Curados
                </span>
              </a>
            </div>

            {/* Desktop Navigation */}
            <nav className="hidden lg:flex items-center gap-6">
              {navLinks.map((link) => (
                <a
                  key={link.name}
                  id={`nav-desktop-${link.name.toLowerCase()}`}
                  href={link.href}
                  className="font-sans text-xs font-semibold tracking-wider text-stone-700 hover:text-terracotta-700 uppercase transition-colors"
                >
                  {link.name}
                </a>
              ))}
            </nav>

            {/* Action Buttons */}
            <div className="hidden sm:flex items-center gap-3">
              <a
                href="https://wa.me/525620654031?text=Hola%2C%20vi%20sus%20curados%20artesanales%20en%20la%20web%20y%20quiero%20hacer%20un%20pedido."
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold tracking-wider uppercase px-4 py-2.5 rounded-lg border border-emerald-500/50 hover:border-emerald-400 transition-all duration-300"
              >
                <MessageCircle className="w-4 h-4" />
                <span>+52 562 065 4031</span>
              </a>
            </div>

            {/* Mobile menu button */}
            <div className="lg:hidden">
              <button
                id="mobile-menu-toggle"
                onClick={() => setIsOpen(!isOpen)}
                className="p-2 text-stone-700 hover:text-terracotta-700 hover:bg-stone-100 rounded-xl transition-colors"
                aria-label="Toggle menu"
              >
                {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        <AnimatePresence>
          {isOpen && (
            <motion.div
              id="mobile-menu-drawer"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
              className="absolute left-4 right-4 mt-2 p-6 rounded-2xl bg-white border border-terracotta-200 shadow-2xl flex flex-col gap-6 lg:hidden"
            >
              <nav className="flex flex-col gap-4">
                {navLinks.map((link) => (
                  <a
                    key={link.name}
                    id={`nav-mobile-${link.name.toLowerCase()}`}
                    href={link.href}
                    onClick={() => setIsOpen(false)}
                    className="font-sans text-sm font-semibold tracking-wider text-stone-800 hover:text-terracotta-700 uppercase border-b border-stone-100 pb-2 transition-colors"
                  >
                    {link.name}
                  </a>
                ))}
              </nav>

              <div className="flex flex-col gap-4 pt-2">
                <a
                  href="https://wa.me/525620654031?text=Hola%2C%20vi%20sus%20curados%20artesanales%20en%20la%20web%20y%20quiero%20hacer%20un%20pedido."
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white text-sm font-bold tracking-wider uppercase py-3 rounded-lg border border-emerald-500/50 transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>+52 562 065 4031</span>
                </a>

                {/* Micro Socials */}
                <div className="flex items-center justify-center gap-6 mt-2 text-gray-400">
                  <a
                    href="https://instagram.com/dafma.mezcal"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-amber-gold transition-colors"
                  >
                    <Instagram className="w-5 h-5" />
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="hover:text-amber-gold transition-colors"
                  >
                    <Facebook className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </header>
    </>
  );
}

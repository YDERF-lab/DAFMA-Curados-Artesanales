import React from "react";
import { motion } from "motion/react";
import { Compass, Eye, Heart, Landmark, MapPin, Sparkles } from "lucide-react";
import { VALUE_CARDS, IMAGES } from "../data";

const iconMap: Record<string, React.ReactNode> = {
  Compass: <Compass className="w-8 h-8 text-amber-gold" />,
  Eye: <Eye className="w-8 h-8 text-amber-gold" />,
  Heart: <Heart className="w-8 h-8 text-amber-gold" />
};

export default function AboutUs() {
  return (
    <section id="nosotros" className="relative py-24 sm:py-32 bg-[#fcfaf6] overflow-hidden">
      {/* Subtle traditional mexican grid watermark in the background */}
      <div className="absolute inset-0 mexican-pattern mix-blend-color opacity-3 pointer-events-none" />

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Story Grid Section */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          {/* Narrative Content */}
          <div className="lg:col-span-7 space-y-8">
            <div className="space-y-3">
              <span className="font-mono text-xs text-terracotta-600 font-bold tracking-[0.2em] uppercase block">
                Nuestra Historia & Raíces
              </span>
              <h2 className="font-serif text-3xl sm:text-5xl text-terracotta-950 font-semibold tracking-tight">
                El encuentro de dos Tierras sagradas:<br />
                <span className="text-terracotta-750 font-serif italic font-normal">Tehuacán y Huajuapan de León</span>
              </h2>
            </div>

            <div className="h-1 w-20 bg-terracotta-600 rounded" />

            <div className="font-sans text-stone-700 space-y-6 leading-relaxed">
              <p>
                <strong>DAFMA Curados</strong> nace del orgullo familiar y de un profundo respeto por las tradiciones de la mixteca mexicana. Nuestro origen se arraiga en la armoniosa unión de dos emblemáticas regiones: 
                <span className="text-terracotta-950 font-bold"> Tehuacán, Puebla</span> y 
                <span className="text-terracotta-950 font-bold"> Huajuapan de León, Oaxaca</span>. Esta confluencia geográfica y cultural nos inspiró a fusionar el misticismo del mejor Mezcal de las tierras oaxaqueñas con los sabores frutales más vibrantes y tradicionales de la región.
              </p>
              
              <p>
                ¿Quiénes somos? Somos artesanos contemporáneos convencidos de que el mezcal es un ente vivo con el que se dialoga. En vez de competir con la fuerza del destilado, creamos un lazo armónico: maceraciones pausadas de frutas locales cosechadas en su plenitud, azúcar de agave orgánica y un proceso celoso de experimentación que respeta el carácter ahumado del agave Espadín.
              </p>

              <p className="border-l-4 border-terracotta-600 pl-4 italic text-terracotta-800 font-serif text-lg bg-terracotta-50/50 py-2 pr-2 rounded-r-lg">
                "No hacemos mezcal para olvidar, creamos curados para celebrar la herencia y revivir la memoria de México en cada trago."
              </p>
            </div>

            {/* Geographical Badges */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <div className="flex items-center gap-3 p-4 rounded-xl bg-white border border-terracotta-100 shadow-sm">
                <div className="p-2.5 rounded-lg bg-terracotta-50 text-terracotta-600">
                  <MapPin className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-terracotta-950 text-sm">Tehuacán, Puebla</h4>
                  <p className="text-xs text-stone-500 font-sans">Cuna del maíz e ingredientes finos</p>
                </div>
              </div>

              <div className="flex items-center gap-3 p-4 rounded-xl bg-white border border-terracotta-100 shadow-sm">
                <div className="p-2.5 rounded-lg bg-emerald-50 text-emerald-700">
                  <Landmark className="w-5 h-5" />
                </div>
                <div>
                  <h4 className="font-serif font-bold text-terracotta-950 text-sm">Huajuapan de León</h4>
                  <p className="text-xs text-stone-500 font-sans">Corazón de la Mixteca Oaxaqueña</p>
                </div>
              </div>
            </div>
          </div>

          {/* Visual Showcase Box representing craftsmanship */}
          <div className="lg:col-span-5 relative">
            <div className="relative mx-auto max-w-sm lg:max-w-none">
              
              {/* Outer decorative ring representing sun/ancient calendar wheel */}
              <div className="absolute inset-0 border-2 border-dashed border-amber-gold/20 rounded-full animate-spin-slow p-8 pointer-events-none" style={{ animationDuration: '60s' }} />

              <div className="relative z-10 bg-white border border-terracotta-200/90 p-8 sm:p-10 rounded-2xl shadow-xl space-y-6">
                <div className="flex justify-between items-center">
                  <span className="font-mono text-[10px] text-terracotta-800 border border-terracotta-300 px-2.5 py-0.5 rounded-full uppercase font-semibold">
                    Autenticidad
                  </span>
                  <img
                    src={IMAGES.brandLogo}
                    alt="Sello de Autenticidad DAFMA"
                    className="w-12 h-12 object-contain rounded-full border border-amber-gold/40 shadow-inner bg-terracotta-50/50"
                    referrerPolicy="no-referrer"
                  />
                </div>

                <h3 className="font-serif text-2xl text-terracotta-950 font-semibold">El Compromiso DAFMA</h3>
                
                <ul className="space-y-4 font-sans text-sm text-stone-700">
                  <li className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-terracotta-600 mt-2 shrink-0" />
                    <span><strong>100% Sin Conservadores:</strong> Todo el dulzor y el cuerpo provienen de la fruta natural de temporada y la melaza pura.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-terracotta-600 mt-2 shrink-0" />
                    <span><strong>Maceración Manual:</strong> Seguimos ritos tradicionales filtrando gota a gota mediante cedazos de lienzo vegetal.</span>
                  </li>
                  <li className="flex items-start gap-2.5">
                    <span className="w-1.5 h-1.5 rounded-full bg-terracotta-600 mt-2 shrink-0" />
                    <span><strong>Sustentabilidad:</strong> Proveemos ingresos dignos a familias campesinas mixtecas con comercio ético.</span>
                  </li>
                </ul>

                <hr className="border-stone-150" />

                <div className="flex justify-between items-center text-xs font-mono">
                  <div>
                    <p className="text-terracotta-700 font-bold text-lg">60 - 80</p>
                    <p className="text-stone-500">Botellas / Mes</p>
                  </div>
                  <div className="text-right">
                    <p className="text-terracotta-700 font-bold text-lg">7 - 15</p>
                    <p className="text-stone-500">Días Maceración</p>
                  </div>
                </div>
              </div>

              {/* absolute decorative card back shadow */}
              <div className="absolute -inset-1.5 bg-gradient-to-r from-terracotta-700 to-amber-gold rounded-2xl blur-lg opacity-20 -z-10" />
            </div>
          </div>
        </div>
        {/* Philosophy - Mission, Vision, Values Row */}
        <div id="filosofia" className="mt-32 pt-16 border-t border-terracotta-200/50 space-y-12">
          <div className="text-center max-w-2xl mx-auto space-y-3">
            <span className="font-mono text-xs text-terracotta-700 font-bold tracking-[0.2em] uppercase">
              Pilares Fundacionales
            </span>
            <h3 className="font-serif text-3xl sm:text-4xl text-terracotta-950 font-semibold">
              Nuestra Misión, Visión y Valores
            </h3>
            <p className="font-sans text-sm text-stone-550">
              Guiados por el legado familiar de compartir momentos memorables de unión cultural.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {VALUE_CARDS.map((val, idx) => (
              <motion.div
                key={val.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-100px" }}
                transition={{ duration: 0.5, delay: idx * 0.15 }}
                className="relative bg-white border border-terracotta-150 hover:border-terracotta-400 p-8 rounded-2xl transition-all duration-300 shadow-sm hover:shadow-md group"
              >
                {/* Micro ornament on card top */}
                <span className="absolute top-4 right-4 text-xs font-mono text-stone-400 group-hover:text-terracotta-500 transition-colors">
                  0{idx + 1}
                </span>

                <div className="p-3 bg-terracotta-50/50 w-fit rounded-xl border border-terracotta-100 mb-6 group-hover:bg-terracotta-50 transition-colors">
                  {iconMap[val.icon]}
                </div>

                <h4 className="font-serif text-xl text-terracotta-950 font-bold mb-4 group-hover:text-terracotta-700 transition-colors">
                  {val.title}
                </h4>

                <p className="font-sans text-sm text-stone-700 leading-relaxed">
                  {val.description}
                </p>

                {/* Hover decorative border accent */}
                <div className="absolute bottom-0 left-0 right-0 h-1 rounded-b-2xl bg-gradient-to-r from-terracotta-600 to-amber-gold opacity-0 group-hover:opacity-100 transition-opacity" />
              </motion.div>
            ))}
          </div>
        </div>

      </div>
    </section>
  );
}

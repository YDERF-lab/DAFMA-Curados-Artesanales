import React from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import AboutUs from "./components/AboutUs";
import Products from "./components/Products";
import Process from "./components/Process";
import TargetPublic from "./components/TargetPublic";
import Distribution from "./components/Distribution";
import ContactFooter from "./components/ContactFooter";
import { Sparkles, Beer, Wine, Flame } from "lucide-react";

export default function App() {
  return (
    <div id="app-root-container" className="bg-[#faf7f2] min-h-screen font-sans text-stone-850 antialiased selection:bg-terracotta-700 selection:text-white overflow-x-hidden relative">
      
      {/* Absolute Decorative Watermarks / Traditional Noise Accent */}
      <div className="fixed inset-0 pointer-events-none z-50 bg-[radial-gradient(#cf5c16_0.5px,transparent_0.5px)] [background-size:16px_16px] [mask-image:radial-gradient(ellipse_50%_50%_at_50%_50%,#000_10%,transparent_100%)] opacity-15" />

      {/* Persistent WhatsApp Floating Button for Ultimate Mobile Conversion */}
      <a
        id="floating-whatsapp-trigger"
        href="https://wa.me/525620654031?text=Hola%2C%20vi%20sus%20curados%20artesanales%20en%20la%20web%20y%20quiero%20hacer%20un%20pedido."
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 p-4 bg-emerald-600 hover:bg-emerald-500 hover:scale-110 active:scale-95 text-white rounded-full shadow-2xl transition-all duration-300 border border-emerald-400 group cursor-pointer"
        aria-label="Pedir por WhatsApp de forma de botón flotante"
      >
        <span className="absolute right-full mr-3 bg-white border border-terracotta-200 text-terracotta-800 font-semibold font-sans text-xs uppercase tracking-widest px-3 py-1.5 rounded-xl opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap shadow-xl">
          ¿Listo para probar?
        </span>
        <svg className="w-6 h-6 fill-current" viewBox="0 0 24 24">
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.724-1.455L0 24zm6.59-4.846c1.6.95 3.1 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.965C16.528 2.023 14.1 1 11.53 1c-5.44 0-9.866 4.372-9.87 9.802 0 1.763.475 3.486 1.38 5.025l-.949 3.464 3.556-.937zm11.367-7.39l-2.454-1.18c-.285-.136-.455-.102-.653.136l-1.023 1.246c-.198.239-.397.272-.682.136-1.511-.643-2.646-1.5-3.612-2.463-.255-.255-.404-.543-.136-.882.239-.301.402-.454.545-.61.14-.156.198-.268.297-.478.099-.21.049-.395-.025-.543l-1.09-2.585c-.282-.67-.58-.58-.795-.58l-.68-.01c-.233 0-.613.087-.936.43-.323.344-1.233 1.205-1.233 2.938 0 1.733 1.265 3.411 1.442 3.65.177.24 2.49 3.8 6.031 5.332 2.113.912 2.946.983 4.025.823 1.077-.16 2.453-.997 2.793-1.914.34-.918.34-1.705.238-1.874-.102-.169-.374-.27-.658-.406z" />
        </svg>
      </a>

      {/* Headers navigation */}
      <Header />

      {/* Linear structure sections path */}
      <main id="main-content-flow" className="relative">
        <Hero />
        <AboutUs />
        <Products />
        <Process />
        <TargetPublic />
        <Distribution />
        <ContactFooter />
      </main>

    </div>
  );
}
